import React, { useState } from 'react';

export default function ChatTutor({ apiKey, baseUrl, tenantId, userId }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  async function send() {
    const body = {
      session_id: null,
      user_id: userId,
      history: [...messages.map(m => ({ role: m.role, text: m.text })), { role: 'student', text: input }],
      target_difficulty_adjust: 0
    };
    const res = await fetch(`${baseUrl}/tenants/${tenantId}/tutor/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    setMessages([...messages, { role: 'student', text: input }, { role: 'tutor', text: data.response }]);
    setInput('');
  }

  return (
    <div style={{ border: '1px solid #ddd', padding: 12, borderRadius: 8, width: 400 }}>
      <div style={{ height: 200, overflow: 'auto', marginBottom: 8 }}>
        {messages.map((m, i) => <div key={i} style={{ margin: 6, textAlign: m.role==='student' ? 'right' : 'left' }}>
          <b>{m.role}</b>: {m.text}
        </div>)}
      </div>
      <div style={{ display: 'flex' }}>
        <input value={input} onChange={e => setInput(e.target.value)} style={{ flex: 1 }} />
        <button onClick={send}>Send</button>
      </div>
    </div>
  );
}
