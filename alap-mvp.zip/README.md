# ALAP-MVP (Adaptive Learning AI Platform) - Minimal MVP Scaffold

This repository is a **minimal, runnable MVP scaffold** for the Adaptive Learning AI Platform (ALAP).
It includes:
- FastAPI backend with core endpoints and OpenAPI specification.
- Dockerfile + docker-compose (Postgres).
- Simple JS SDK and a small React tutor widget component.
- OpenAPI YAML (openapi.yaml).
- GitHub Actions CI workflow skeleton.

**How to run (local dev)**

Requirements: Docker & Docker Compose

1. Start local services:
   ```
   docker-compose up --build
   ```

2. Backend will be available at `http://localhost:8000`.
   Swagger UI: `http://localhost:8000/docs`

3. Example usage:
   - Use the JS SDK in `sdk/` for simple calls.
   - The React widget in `widget/` is a standalone component.

**What this MVP includes (scaffold)**
- `backend/` : FastAPI app with endpoints:
  - `/auth/token`
  - `/tenants/{tenant_id}/content`
  - `/tenants/{tenant_id}/problems/generate`
  - `/tenants/{tenant_id}/tutor/chat`
  - `/tenants/{tenant_id}/users/{user_id}/next`
  - `/events`

> This is a scaffold for rapid development — replace mock logic with production integrations:
> - Replace mock LLM calls with OpenAI/Anthropic/your-hosted LLM.
> - Add vector DB (Pinecone/Weaviate/RedisVector) & embedding pipeline.
> - Add proper auth, billing, tenancy enforcement, and production-grade observability.

