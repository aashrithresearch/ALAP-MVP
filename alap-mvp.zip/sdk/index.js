export default class ALAP {
  constructor({ apiKey, baseUrl }) {
    this.apiKey = apiKey;
    this.baseUrl = baseUrl || "http://localhost:8000";
  }

  async _fetch(path, opts = {}) {
    const url = this.baseUrl + path;
    const headers = opts.headers || {};
    headers['Content-Type'] = 'application/json';
    if (this.apiKey) headers['X-API-Key'] = this.apiKey;
    const res = await fetch(url, { ...opts, headers });
    return res.json();
  }

  async recommendNext(tenantId, userId) {
    return this._fetch(`/tenants/${tenantId}/users/${userId}/next`);
  }

  async tutorChat(tenantId, body) {
    return this._fetch(`/tenants/${tenantId}/tutor/chat`, { method: 'POST', body: JSON.stringify(body) });
  }

  async generateProblems(tenantId, body) {
    return this._fetch(`/tenants/${tenantId}/problems/generate`, { method: 'POST', body: JSON.stringify(body) });
  }
}
