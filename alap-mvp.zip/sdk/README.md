Simple JavaScript SDK (lightweight). Example usage in Node or browser environments.
