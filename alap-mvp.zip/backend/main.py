from fastapi import FastAPI, HTTPException, Path
from pydantic import BaseModel, Field
from typing import List, Optional, Any
from uuid import uuid4
import time

app = FastAPI(title="Adaptive Learning AI Platform (MVP)")

# --- Schemas ---
class TokenRequest(BaseModel):
    client_id: str
    client_secret: str
    grant_type: str

class ContentIn(BaseModel):
    title: str
    type: str
    body: str
    tags: Optional[List[str]] = []
    difficulty_hint: Optional[int] = 1

class ProblemGenIn(BaseModel):
    topic: str
    difficulty: int = 1
    format: str = "multiple_choice"
    num_variants: int = 1
    seed: Optional[int] = None

class TutorMessage(BaseModel):
    role: str
    text: str

class TutorChatIn(BaseModel):
    session_id: Optional[str]
    user_id: str
    history: List[TutorMessage] = []
    target_difficulty_adjust: Optional[int] = 0

class RecommendationOut(BaseModel):
    content_id: str
    reason: str
    estimated_time_min: int

class EventItem(BaseModel):
    type: str
    ts: str
    payload: dict

class EventsIn(BaseModel):
    tenant_id: str
    user_id: str
    events: List[EventItem]

# --- In-memory stores (mocks) ---
CONTENT_DB = {}
PROBLEMS_DB = {}
SESSIONS = {}

# --- Endpoints ---
@app.post("/auth/token")
async def auth_token(req: TokenRequest):
    if req.grant_type != "client_credentials":
        raise HTTPException(status_code=400, detail="unsupported grant_type")
    # Mock token
    return {"access_token": "mocK-"+str(int(time.time())), "expires_in": 3600, "token_type": "bearer"}

@app.post("/tenants/{tenant_id}/content", status_code=201)
async def ingest_content(tenant_id: str = Path(...), payload: ContentIn = None):
    cid = "c-" + str(uuid4())
    CONTENT_DB[cid] = {"id": cid, "tenant_id": tenant_id, "title": payload.title, "type": payload.type, "body": payload.body, "tags": payload.tags, "difficulty_hint": payload.difficulty_hint}
    return {"id": cid}

@app.post("/tenants/{tenant_id}/problems/generate")
async def generate_problems(tenant_id: str = Path(...), payload: ProblemGenIn = None):
    out = []
    for i in range(payload.num_variants):
        pid = "p-" + str(uuid4())
        q = f"Example {payload.topic} problem (difficulty {payload.difficulty}) variant {i+1}"
        choices = ["A","B","C","D"]
        PROBLEMS_DB[pid] = {"id": pid, "question": q, "choices": choices, "answer": "A", "explanation": "Example explanation."}
        out.append(PROBLEMS_DB[pid])
    return {"problems": out}

@app.post("/tenants/{tenant_id}/tutor/chat")
async def tutor_chat(tenant_id: str = Path(...), payload: TutorChatIn = None):
    # Simple mock: echo last student message with hints
    session = payload.session_id or "sess-" + str(uuid4())
    last_student = None
    for m in reversed(payload.history):
        if m.role == "student":
            last_student = m.text
            break
    if not last_student:
        reply = "Hi! What would you like help with?"
    else:
        reply = f"I see you asked: '{last_student}'. Let's break it into steps. (mock tutor reply)"
    # store session
    SESSIONS[session] = {"tenant_id": tenant_id, "user_id": payload.user_id, "last_reply": reply}
    return {"response": reply, "references": []}

@app.get("/tenants/{tenant_id}/users/{user_id}/next")
async def next_activity(tenant_id: str = Path(...), user_id: str = Path(...)):
    # Mock recommendation
    return {"next_items": [{"content_id": "c-example", "reason": "knowledge_gap", "estimated_time_min": 10}], "policy_version": "v1-mock"}

@app.post("/events", status_code=202)
async def ingest_events(payload: EventsIn):
    # In production you'd enqueue to Kafka or a data pipeline
    # Here we just acknowledge
    return {"status": "accepted", "received": len(payload.events)}
