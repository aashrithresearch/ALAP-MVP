Backend (FastAPI) - quickstart

From repo root:
  docker-compose up --build

API docs: http://localhost:8000/docs
OpenAPI YAML: /openapi.yaml
